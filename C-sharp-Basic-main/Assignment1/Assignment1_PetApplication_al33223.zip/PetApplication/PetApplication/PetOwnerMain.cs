﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*******************************************************************************************
 * Author: Vilhelm Park
 * Date: 2020-09-07
 * Description: This application calls for the pet object and input values to it and then
 *              outputs the values.
 *******************************************************************************************/

namespace PetApplication
{
    class PetOwnerMain
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Title = "Pet owner";
            Pet pet = new Pet();
            pet.ReadAndSavePetData();
            pet.outputPetInformation();
            Console.Write("Press Enter to exit!");
            Console.ReadLine();
        }
    }
}
