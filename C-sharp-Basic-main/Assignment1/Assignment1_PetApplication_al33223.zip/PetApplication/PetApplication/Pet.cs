﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*******************************************************************************************
 * Author: Vilhelm Park
 * Date: 2020-09-07
 * Description: This class has getters for the private fields in the plant. 
 *              We have a method that reads input and sets the values in the private fields.
 *              Then we have a method for output the private fields in a nice manner.
 *******************************************************************************************/

namespace PetApplication
{
    class Pet
    {
        private string name;
        private int age;
        private bool isFemale;

        public void ReadAndSavePetData()
        { 
            Console.Write("What's your pets name? \nEnter name: ");
            name = Console.ReadLine();
            Console.Write("What's the age of " + name + "? \nEnter age: ");
            string ageString = Console.ReadLine();
            age = int.Parse(ageString);
            Console.Write("Is " + name + " a male or female?" + "\nEnter gender (M/F): ");
            string gender = Console.ReadLine();

            if(gender == "M" || gender == "m")
            {
                isFemale = false;
            }
            else
            {
                isFemale = true;
            }
        }

        public void outputPetInformation()
        {
            Console.WriteLine("++++++++++++++++++++++++++");
            Console.Write("Name: " + getName() + " Age: " + getAge()
                + "\n" + getName() + " is a good ");

            if (getGender() == true)
            {
                Console.Write("girl!\n++++++++++++++++++++++++++\n");
            }
            else
            {
                Console.Write("boy!\n++++++++++++++++++++++++++\n");
            }
        }

        public string getName ()
        {
            return name;
        }

        public int getAge()
        {
            return age;
        }

        public bool getGender()
        {
            return isFemale;
        }
    }
}
